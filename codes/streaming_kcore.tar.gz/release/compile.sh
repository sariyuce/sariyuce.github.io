make clean;MAINTAIN_CD=yes make -e -j8;mv stkcore stkcoreRCD;
make clean;make -e -j8;
