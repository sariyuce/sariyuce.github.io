/*
    Algorithm 01: k-CliqueGen(k)    [k-Clique Generator]
 */

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <unordered_map>

using namespace std;

/*
        Global Variables
*/

unordered_map<string,int> cliqueMap;   // for tracking the duplicate of a clique
int cliqueValue;                      //  value of clique (Global)


// generating all K combination out of N numbers

void writeCombination(vector<int> &arr, unsigned long N, ofstream &file)
{
    string bitmask(cliqueValue, 1); // K leading 1's
    bitmask.resize(N, 0);           // N-K trailing 0's
    
    do {
        string clique;
        
        for (int i = 0; i < N; ++i) // [0..N-1] integers
        {
            if (bitmask[i])
                clique = clique + to_string(arr[i]) + " ";
        }
        
        if(cliqueMap[clique] == 0){
            file << clique;
            file << "\n";
            cliqueMap[clique]++;
        }
    } while (prev_permutation(bitmask.begin(), bitmask.end()));
}


/*
 
 How to run :
    need two command line arguments : Input-file-name, clique value (3/4/5...../10)
   ex: ./main erdos-max-cliques-sorted.out 5
 
*/

int main(int argc, char** argv)
{
    
    // checking command line arguments
    if (argc != 3) {
        fprintf(stderr, "usage: %s input-file-name VALUE_FOR_CLIQUE", argv[0]);
        exit(1);
    }

    
    // Parsing command line arguments
    string inputFile  = argv[1];
    string outputFile = inputFile.substr(0, inputFile.find("-")) + "_" + argv[2] + "_Cliques.txt";
    
    // File pointers
    ifstream in;
    ofstream out;
    
    in.open(inputFile);
    out.open(outputFile);
    
    if (!in)
    {
        cout << "Error in opening the input file \n";
        return 1;
    }
    
    cliqueValue = stoi(argv[2]); // cliqueValue is a global variable (type : int)
    string line;
    vector<int> vertices;
    string vertex_id;
    
    while(!in.eof()){
        
        getline(in,line); // Read every line
        
        if(line.length()==0)
            break;
        
        // Extract the vertices id from the line
        stringstream ss(line);  // Turn the string into a stream
        vertices.clear();
        
        while(getline(ss, vertex_id, ' ')) {
            vertices.push_back(stoi(vertex_id));
        }
        
        unsigned long n = vertices.size();
        
        if(n >= cliqueValue){
            writeCombination(vertices,n,out);
        }
    }
    
    // Closing file streams
    in.close();
    out.close();
}
