Each dataset (e.g. out.caida) represents a **simple** and **undirected** graph. For every dataset we will generate all cliques ( 3 clique to  10 clique ) in a file.

###  Format of the dataset :
Every line contains two end vertices of an edge. 
**Example**:   
A graph with edges (0, 1),  (2, 0),  (1, 3),  (2, 3):
0 1  
2 0  
1 3  
2 3  

### Using **`mace`** code :

We will get all the **maximal cliques** of a graph (dataset)  by running `mace` code. Please read the `readme.txt` file in `mace` folder to get details about how to use the code.

First, we need to convert the format of our dataset files to the format of `mace` code by using a perl script :  `transgrh.pl` 

The command is given below :  
```
./transgrh.pl [separator] <input-file> output-file
```
By default the seperator is : `" " ` 
**e.g.**  If the input-file is **out.abc** and name of the output file will be **abc.grh** then the command will be :  
```
./transgrh.pl <out.abc> abc.grh 
```

Then we will run `mace` code for generating all maximal cliques. The command is given below :  

```
./mace MS input-file output-file
```

**e.g.** If the input-file is **abc.grh** and name of the output file will be **abc-max-cliques.out** then the command will be:  

```
./mace MS abc.grh abc-max-cliques.out
```

Finally, we will `sort` the output files of `mace` by using another perl script :  `sortout.pl`

The command is given below :,

```
./sortout.pl < input-file > output-file
```

**input-file** is the name of file to which mace output, and the sorted output will be written in the file of the name **output-file**.

**e.g.**  If the input-file is **abc-max-cliques.out** and name of the output file will be **abc-max-cliques-sorted.out** then the command will be:  

```
./sortout.pl < abc-max-cliques.out > abc-max-cliques-sorted.out
```

The vertices of each clique will be **sorted** in the increasing order of indices, and all the cliques (lines) will be also sorted, by the lexicographical order (considered as a string).

#### How to generate all  cliques of a specific value :

To compile  `main.cpp` run the below command :  

```
make main
```
An executable file named `main` will be created in that location. So, you can execute `main`. The format is given below :  

```
./main input-file clique_value
```
Here, `input-file` will contain all maximal cliques of a graph. Each line of the file lists the vertices of a maximal clique. The vertices must be in **sorted** order.  

**e.g.**  If the input-file is **abc-max-cliques-sorted.out** and value of clique is `5` then the command will be:  

```
./main abc-max-cliques-sorted.out 5
```

After execution **one new file** named `abc_5_Cliques.txt` will be created which will contain all the cliques.











