#include "main.h"
#define MAXLINE 1000000

inline void threeWay (vector<vertex>& x, vector<vertex>& y, vector<vertex>& z, vector<vertex>& commonNeighbors) {
    
    vertex i = 0, j = 0, k = 0;
    
    while (i < x.size() && j < y.size() && k < z.size()) {
        
        vertex a = x[i];
        vertex b = y[j];
        vertex c = z[k];
        
        if (a == b && a == c) {
            commonNeighbors.push_back(a);
            i++; j++; k++;
        }
        else {
            vertex m = max ({a, b, c});
            if (a != m)
            i++;
            if (b != m)
            j++;
            if (c != m)
            k++;
        }
    }
}


// read all 3-cliques from the file and save each 3-clique according to "degree ordering" of the vertices in a 3-clique

void create_ThreeCliqueList(Graph& graph, char *rCliqueFilename, vector<triple>& tc, vector<vertex>& xtc, unordered_map<string,int>& umap, unordered_map<string,int>& umapID){
    
    char* line = (char*) malloc (sizeof (char) * MAXLINE);
    FILE* fp = fopen(rCliqueFilename, "r");
    
    vertex u,v,w;
    
    vector<couple> temp;  // tuple <vertex, vertex> --> couple
    
    while (fgets(line, MAXLINE, fp)) {
        
        stringstream ss (line);
        ss >> u >> v >> w;
        
        // ordering the vertices based on degree 
        temp.push_back ( make_tuple (graph[u].size(),u) );
        temp.push_back ( make_tuple (graph[v].size(),v) );
        temp.push_back ( make_tuple (graph[w].size(),w) );
        
        sort (temp.begin(), temp.end());
        
        u = get<1>(temp[0]);
        v = get<1>(temp[1]);
        w = get<1>(temp[2]);
        
        tc.push_back(make_tuple (u, v, w)); // deg(u) < deg(v) < deg(w). If deg is equal then vertex # is taken into consideration for breaking tie.
        
        temp.clear();
    
    }
    
    sort(tc.begin(), tc.end());

    // create "xtc" structure to track where the edge changes in the list of 3-cliques
    
    xtc.push_back(0);
    
    for (int i = 1; i < tc.size(); i++){
        
        if( get<0>(tc[i]) == get<0>(tc[i-1]) && get<1>(tc[i]) == get<1>(tc[i-1]))
           continue;
        else
           xtc.push_back(i);
    }
    
   // initial 4-clique count is 0 for every 3-clique and store the index (in "tc" vector) of all 3-cliques
    
    for (int i = 0; i < tc.size(); i++){
        
        string temp = to_string(get<0>(tc[i])) + " " + to_string(get<1>(tc[i])) + " " + to_string(get<2>(tc[i]));
        
        umap[temp] = 0;
        umapID[temp] = i;
    }
}



// read 4-cliques from the file. Generate all 3-cliques (degree ordered) from a 4-clique and increment count for each 3-clique

void count_ThreeCliquesFrequency (Graph& graph, char *sCliqueFilename, unordered_map<string,int>& umap, unordered_map<string,int>& umapID, int* maX){
    
    char* line = (char*) malloc (sizeof (char) * MAXLINE);
    FILE* fp = fopen(sCliqueFilename, "r");
    
    vertex u,v,w,x;
    
    vector<couple> temp;  // tuple<vertex, vertex> --> couple
    
    while (fgets(line, MAXLINE, fp)) {
        
        stringstream ss (line);
        ss >> u >> v >> w >> x;
        
        temp.push_back ( make_tuple (graph[u].size(),u) );
        temp.push_back ( make_tuple (graph[v].size(),v) );
        temp.push_back ( make_tuple (graph[w].size(),w) );
        temp.push_back ( make_tuple (graph[x].size(),x) );
        
        sort (temp.begin(), temp.end());
        
        u = get<1>(temp[0]);
        v = get<1>(temp[1]);
        w = get<1>(temp[2]);
        x = get<1>(temp[3]);
        
        temp.clear();
        
        /* 4-clique : u, v, w, x,
         There is 4 3-cliques : (4 choose 3 = 4 combination)
             u, v, w
             u, v, x
             u, w, x
             v, w, x
        */
        
        string temp1 = to_string(u) + " " + to_string(v) + " " + to_string(w);
        string temp2 = to_string(u) + " " + to_string(v) + " " + to_string(x);
        string temp3 = to_string(u) + " " + to_string(w) + " " + to_string(x);
        string temp4 = to_string(v) + " " + to_string(w) + " " + to_string(x);
      
        
        umap[temp1]++;
        umap[temp2]++;
        umap[temp3]++;
        umap[temp4]++;
        
        int t = max ({ umap[temp1], umap[temp2], umap[temp3], umap[temp4] });
        
        if ( t > *maX)
            *maX = t;
    }
}




void base_k34 (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max34, string vfile, FILE* fp) {
    
    const auto t1 = chrono::steady_clock::now();
    
    vertex nVtx = graph.size();
    
    vector<vp> el;
    vector<vertex> xel;
    Graph orderedGraph;
    
    // function from "main.h" file which will create an "Ordered Graph" from the input "Graph".  [graph ---> orderedGraph]
    createOrderedIndexEdges (graph, el, xel, orderedGraph);
    
    vector<triple> tc;
    vector<vertex> xtc;
    
    // avg time complexity for insert, delete and update is O(1) for unordered_map
    
    unordered_map<string,int> umap;   // store the 4-clique frequency of all 3-cliques
    unordered_map<string,int> umapID; // every 3-clique is stored in a vector (tc). Every 3-clique has an index in the vector. umapID will store the index for all 3-cliques
    
    
    // function for creating the list of 3-cliques
    create_ThreeCliqueList (graph, rCliqueFilename, tc, xtc, umap, umapID);
    
    const auto t2 = chrono::steady_clock::now();
    print_time (fp, "3-Clique enumeration: ", t2 - t1);
    
    
    // 4-clique counting for each 3-clique
    
    const auto f1 = chrono::steady_clock::now();
    int max4cliqueCount = 0;
    
    // Function for counting 4-clique frequency for each 3-clique.
    count_ThreeCliquesFrequency (graph, sCliqueFilename, umap, umapID, &max4cliqueCount);
    
    
    fprintf (fp, "# 3-cliques: %lld\n", tc.size());
    
    const auto f2 = chrono::steady_clock::now();
    print_time (fp, "4-clique counting for every 3-clique: ", f2 - f1);
    
    
    
    //  ###  Peeling ####
    
   const auto p1 = chrono::steady_clock::now();
    
   K.resize (tc.size(), -1);
   Naive_Bucket nBucket;
   
   nBucket.Initialize (max4cliqueCount, tc.size());

   for (int i = 0; i < tc.size(); i++){
        
       string temp = to_string(get<0>(tc[i])) + " " + to_string(get<1>(tc[i])) + " " + to_string(get<2>(tc[i]));
       
       if (umap[temp] > 0){
           nBucket.Insert ( umapID[temp], umap[temp] );
       }
       else{
           K[umapID[temp]] = 0;
       }
    }
    
    vertex fc_t = 0;
    
    umapVec umapK;
    umapVec umapS;
    vector<vertex> cliqueVertices;
    
    vector<couple> ksValues;       // store all Kappa and S values
    
    /* HIERARCHY RELATED */
    
    vertex cid;
    vector<subcore> skeleton;
    vector<vertex> component;
    vector<vp> relations;
    vector<vertex> unassigned;
    vertex nSubcores;
    
    if (hierarchy) {
        cid = 0;
        nSubcores = 0;
        component.resize (tc.size(), -1);
    }
    
    
    
    while (true) {
        edge t;
        edge val ;
        if (nBucket.PopMin(&t, &val)) // if the bucket is empty
            break;

        fc_t = K[t] = val;            // t is the id of the 3-clique. so need to find out the vertices for this 3-clique
        
        // The below 3-clique is included in a 4-clique which has another 3 3-cliques. These 3-cliques are neighbor 3-cliques.
        
        vertex u = get<0> (tc[t]);
        vertex v = get<1> (tc[t]);
        vertex w = get<2> (tc[t]);
        
        
        string tmp = to_string(u) + " " + to_string(v) + " " + to_string(w);
        // Testing
        //cout << "PoppedID : " << t << " , Popped k Value : " << K[t] << " , Frequency : " << umap[tmp] << endl;
        
        // Storing K value and Frequency for every vertex of the current clique
        
        cliqueVertices.push_back(u);
        cliqueVertices.push_back(v);
        cliqueVertices.push_back(w);
        
        saveVertexProperty(cliqueVertices, umapK, umapS, val, umap[tmp]);  // function body is in the "main.h" file
        
        // storing k and s values
        ksValues.push_back(make_tuple (val, umap[tmp]));
  
        cliqueVertices.clear();
        
        vertex cliqueID = umapID[tmp];
        vector<vertex> commonNeighbors;

        threeWay (graph[u], graph[v], graph[w], commonNeighbors);
        
        /* HIERARCHY RELATED */
        if (hierarchy) {
            unassigned.clear();
            subcore sc (val);
            skeleton.push_back (sc);
        }
        
        
        for (auto y : commonNeighbors) {
            
            vector<couple> tempN;
            
            tempN.push_back ( make_tuple (graph[u].size(),u) );
            tempN.push_back ( make_tuple (graph[v].size(),v) );
            tempN.push_back ( make_tuple (graph[w].size(),w) );
            tempN.push_back ( make_tuple (graph[y].size(),y) );
            
            sort (tempN.begin(), tempN.end());
            
            vertex uu = get<1>(tempN[0]);
            vertex vv = get<1>(tempN[1]);
            vertex ww = get<1>(tempN[2]);
            vertex yy = get<1>(tempN[3]);
            
            tempN.clear();
            
            string temp1 = to_string(uu) + " " + to_string(vv) + " " + to_string(ww) ;  // Neighbor 4 clique : u,v,w
            vertex p = umapID[temp1];
            if (p == cliqueID)
                p = -2;
            
            string temp2 = to_string(uu) + " " + to_string(vv) + " " + to_string(yy) ;  // Neighbor 4 clique : u,v,y
            vertex q = umapID[temp2];
            if (q == cliqueID)
                q = -2;
            
            string temp3 = to_string(uu) + " " + to_string(ww) + " " + to_string(yy) ;  // Neighbor 4 clique : u,w,y
            vertex r = umapID[temp3];
            if (r == cliqueID)
                r = -2;
           
            string temp4 = to_string(vv) + " " + to_string(ww) + " " + to_string(yy) ;  // Neighbor 4 clique : v,w,y
            vertex s = umapID[temp4];
            if (s == cliqueID)
                s = -2;
            
           
            if(p==-2){
                p=q;
                q=r;
                r=s;
            }
            else if(q==-2){
                q=r;
                r=s;
            }
            else if(r==-2){
                r=s;
            }
           
            
            if (K[p] == -1 && K[q] == -1 && K[r] == -1) {
                
                if (nBucket.CurrentValue(p) > fc_t)
                    nBucket.DecVal(p);
                
                if (nBucket.CurrentValue(q) > fc_t)
                    nBucket.DecVal(q);
                
                if (nBucket.CurrentValue(r) > fc_t)
                    nBucket.DecVal(r);
            
            }
            else if (hierarchy) // boolean variable
                createSkeleton (t, {p, q, r}, &nSubcores, K, skeleton, component, unassigned, relations);
        }
        if (hierarchy)
            updateUnassigned (t, component, &cid, relations, unassigned);
    }

    nBucket.Free();
    
    *max34 = fc_t;
    
    //cout << " value of maxK : " << fc_t << endl; // Testing
    const auto p2 = chrono::steady_clock::now();
    
    
    // Writing vertex statistics to a file
    
    string rst (rCliqueFilename);
    string outputFile1 = rst.substr(0, rst.find("_")) + "34" + "_vp.txt";
    string outputFile2 = rst.substr(0, rst.find("_")) + "34" + "_vs.txt";
    
    string outputFile3 = rst.substr(0, rst.find("_")) + "34" + "_k_S_values.txt";

    const auto vs1 = chrono::steady_clock::now();
    
    writeVertexProperty  (umapK, umapS, outputFile1);
    writeVertexStatistic (umapK, umapS, outputFile2);
    
    writeKSValues(ksValues, outputFile3);
    
    const auto vs2 = chrono::steady_clock::now();
    
    print_time (fp, "Vertex statistics computing time: ", vs2 - vs1);
    
    if (!hierarchy) {
        print_time (fp, "Only peeling time: ", p2 - p1);
        print_time (fp, "Total time: ", (p2 - p1) + (f2 - f1) + (t2 - t1));
    }
    else {
        print_time (fp, "Only peeling + on-the-fly hierarchy construction time: ", p2 - p1);
        const auto b1 = chrono::steady_clock::now();
        buildHierarchy (*max34, relations, skeleton, &nSubcores, nEdge, nVtx);
        const auto b2 = chrono::steady_clock::now();
        
        print_time (fp, "Building hierarchy time: ", b2 - b1);
        print_time (fp, "Total 3,4 nucleus decomposition time (excluding density computation): ", (p2 - p1) + (t2 - t1) + (b2 - b1));
        
        fprintf (fp, "# subcores: %d\t\t # subsubcores: %d\t\t |V|: %d\n", nSubcores, skeleton.size(), graph.size());
        
        const auto d1 = chrono::steady_clock::now();
        helpers hp (&tc);
        presentNuclei (34, skeleton, component, graph, nEdge, hp, vfile, fp);
        const auto d2 = chrono::steady_clock::now();
        
        print_time (fp, "Total 3,4 nucleus decomposition time: ", (p2 - p1) + (t2 - t1) + (b2 - b1) + (d2 - d1));
    }
}
