#include "main.h"
#define MAXLINE 1000000

inline void fiveWay (vector<vertex>& x, vector<vertex>& y, vector<vertex>& z, vector<vertex>& t1, vector<vertex>& t2, vector<vertex>& commonNeighbors) {
    
    vertex i = 0, j = 0, k = 0, l1 = 0, l2 = 0;
    
    while (i < x.size() && j < y.size() && k < z.size() && l1 < t1.size() && l2 < t2.size()) {
       
        vertex a = x[i];
        vertex b = y[j];
        vertex c = z[k];
        vertex d = t1[l1];
        vertex e = t2[l2];

        if (a == b && a == c && a == d && a == e) {
            commonNeighbors.push_back(a);
            i++; j++; k++; l1++; l2++;
        }
        else {
            vertex m = max ({a, b, c, d, e});
            if (a != m)
                i++;
            if (b != m)
                j++;
            if (c != m)
                k++;
            if (d != m)
                l1++;
            if (e != m)
                l2++;
        }
    }
}

// read all 5 cliques from the file and save each 5 clique according to "degree ordering" of the vertices in a 5 clique
void create_FiveCliqueList(Graph& graph, char *rCliqueFilename, vector<vfive>& fic, vector<vertex>& xfic, unordered_map<string,int>& umap, unordered_map<string,int>& umapID){
    
    char* line = (char*) malloc (sizeof (char) * MAXLINE);
    FILE* fp = fopen(rCliqueFilename, "r");
    
    vertex u,v,w,x,y;
    
    vector<couple> temp;  // tuple <vertex, vertex> --> couple
    
    while (fgets(line, MAXLINE, fp)) {
        
        stringstream ss (line);
        ss >> u >> v >> w >> x >> y;
        
        // ordering the vertices based on degree 
        temp.push_back ( make_tuple (graph[u].size(),u) );
        temp.push_back ( make_tuple (graph[v].size(),v) );
        temp.push_back ( make_tuple (graph[w].size(),w) );
        temp.push_back ( make_tuple (graph[x].size(),x) );
        temp.push_back ( make_tuple (graph[y].size(),y) );
        
        sort (temp.begin(), temp.end());
        
        u = get<1>(temp[0]);
        v = get<1>(temp[1]);
        w = get<1>(temp[2]);
        x = get<1>(temp[3]);
        y = get<1>(temp[4]);
        
        fic.push_back(make_tuple (u, v, w, x, y)); // deg(u) < deg(v) < deg(w) < deg(x) < deg(y). If deg is equal then vertex # is taken into consideration for breaking tie.
        
        temp.clear();
    
    }
    
    sort(fic.begin(), fic.end());

    // create "xfic" structure to track where the four clique changes in the list of five cliques
    xfic.push_back(0);
    
    for (int i = 1; i < fic.size(); i++){
        if( get<0>(fic[i]) == get<0>(fic[i-1]) && get<1>(fic[i]) == get<1>(fic[i-1]) && get<2>(fic[i]) == get<2>(fic[i-1]) && get<3>(fic[i]) == get<3>(fic[i-1]))
           continue;
        else
           xfic.push_back(i);
    }
    
    
   // initial 6 clique count is 0 for every 5 clique and store the index (in "fic" vector) of all 5 cliques
    for (int i = 0; i < fic.size(); i++){
        
        string temp = to_string(get<0>(fic[i])) + " " + to_string(get<1>(fic[i])) + " " + to_string(get<2>(fic[i])) + " " + to_string(get<3>(fic[i])) + " " + to_string(get<4>(fic[i]));
        
        umap[temp] = 0;
        umapID[temp] = i;
    }
}


// read six cliques from the file. Generate all 5 cliques (degree ordered) from a 6 clique and increment count for each 5 clique
void count_FiveCliquesFrequency (Graph& graph, char *sCliqueFilename, unordered_map<string,int>& umap, unordered_map<string,int>& umapID, int* maX){
    
    char* line = (char*) malloc (sizeof (char) * MAXLINE);
    FILE* fp = fopen(sCliqueFilename, "r");
    
    vertex u,v,w,x,y,z;
    
    vector<couple> temp;  // tuple<vertex, vertex> --> couple
    
    while (fgets(line, MAXLINE, fp)) {
        
        stringstream ss (line);
        ss >> u >> v >> w >> x >> y >> z;
        
        temp.push_back ( make_tuple (graph[u].size(),u) );
        temp.push_back ( make_tuple (graph[v].size(),v) );
        temp.push_back ( make_tuple (graph[w].size(),w) );
        temp.push_back ( make_tuple (graph[x].size(),x) );
        temp.push_back ( make_tuple (graph[y].size(),y) );
        temp.push_back ( make_tuple (graph[z].size(),z) );
        
        sort (temp.begin(), temp.end());
        
        u = get<1>(temp[0]);
        v = get<1>(temp[1]);
        w = get<1>(temp[2]);
        x = get<1>(temp[3]);
        y = get<1>(temp[4]);
        z = get<1>(temp[5]);
        
        temp.clear();
        
        /* 6 clique : u, v, w, x, y, z
         There is six 5 cliques : (6 choose 5 = 6 combination)
             u, v, w, x, y
             u, v, w, x, z
             u, v, w, y, z
             u, v, x, y, z
             u, w, x, y, z
             v, w, x, y, z
                            */
        
        string temp1 = to_string(u) + " " + to_string(v) + " " + to_string(w) + " " + to_string(x) + " " + to_string(y);
        string temp2 = to_string(u) + " " + to_string(v) + " " + to_string(w) + " " + to_string(x) + " " + to_string(z);
        string temp3 = to_string(u) + " " + to_string(v) + " " + to_string(w) + " " + to_string(y) + " " + to_string(z);
        string temp4 = to_string(u) + " " + to_string(v) + " " + to_string(x) + " " + to_string(y) + " " + to_string(z);
        string temp5 = to_string(u) + " " + to_string(w) + " " + to_string(x) + " " + to_string(y) + " " + to_string(z);
        string temp6 = to_string(v) + " " + to_string(w) + " " + to_string(x) + " " + to_string(y) + " " + to_string(z);
        
        umap[temp1]++;
        umap[temp2]++;
        umap[temp3]++;
        umap[temp4]++;
        umap[temp5]++;
        umap[temp6]++;
        
        int t = max ({ umap[temp1], umap[temp2], umap[temp3], umap[temp4], umap[temp5], umap[temp6] });
        
        if ( t > *maX)
            *maX = t;
    }
}




void base_k56 (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max56, string vfile, FILE* fp) {
    
    const auto t1 = chrono::steady_clock::now();
    
    vertex nVtx = graph.size();
    
    vector<vp> el;
    vector<vertex> xel;
    Graph orderedGraph;
    
    // function from "main.h" file which will create an "Ordered Graph" from the input "Graph".  [graph ---> orderedGraph]
    createOrderedIndexEdges (graph, el, xel, orderedGraph);
    
    vector<vfive> fic;
    vector<vertex> xfic;
    
    // avg time complexity for insert, delete and update is O(1) for unordered_map
    unordered_map<string,int> umap;   // store the 6 clique frequency of all 5 cliques
    unordered_map<string,int> umapID; // every 5 clique is stored in a vector (fic). Every 5 clique has an index in the vector. umapID will store the index for all 5 cliques
    
    
    // function for creating the list of 5 cliques
    create_FiveCliqueList (graph, rCliqueFilename, fic, xfic, umap, umapID);
    
    const auto t2 = chrono::steady_clock::now();
    print_time (fp, "5-Clique enumeration: ", t2 - t1);
    
    
    // 6-clique counting for each 5-clique
    
    const auto f1 = chrono::steady_clock::now();
    int max6cliqueCount = 0;
    
    // Function for counting 6 cliques for each 5 clique.
    count_FiveCliquesFrequency (graph, sCliqueFilename, umap, umapID, &max6cliqueCount);
    
    fprintf (fp, "# 5-cliques: %lld\n", fic.size());
    
    const auto f2 = chrono::steady_clock::now();
    print_time (fp, "6-clique counting for every 5 clique: ", f2 - f1);
    
    
    //  ###  Peeling ####
    
   const auto p1 = chrono::steady_clock::now();
    
   K.resize (fic.size(), -1);
   Naive_Bucket nBucket;
   
   nBucket.Initialize (max6cliqueCount, fic.size());

   for (int i = 0; i < fic.size(); i++){
        
       string temp = to_string(get<0>(fic[i])) + " " + to_string(get<1>(fic[i])) + " " + to_string(get<2>(fic[i])) + " " + to_string(get<3>(fic[i])) + " " + to_string(get<4>(fic[i]));
       
       if (umap[temp] > 0){
           nBucket.Insert ( umapID[temp], umap[temp] );
       }
       else{
           K[umapID[temp]] = 0;
       }
    }
    
    vertex fc_t = 0;
    
    umapVec umapK;
    umapVec umapS;
    vector<vertex> cliqueVertices;
    
    vector<couple> ksValues;       // store all Kappa and S values
    
    /* HIERARCHY RELATED */
    
    vertex cid;
    vector<subcore> skeleton;
    vector<vertex> component;
    vector<vp> relations;
    vector<vertex> unassigned;
    vertex nSubcores;
    
    if (hierarchy) {
        cid = 0;
        nSubcores = 0;
        component.resize (fic.size(), -1);
    }
    
    
    while (true) {
        edge t;
        edge val ;
        if (nBucket.PopMin(&t, &val)) // if the bucket is empty
            break;

        fc_t = K[t] = val;  // t is the id of the 5 clique. so need to find out the vertices for this 5 clique
        
        // The below 5 clique is included in a 6 clique which has another five 5 cliques. These 5 cliques are neighbor five cliques.
        vertex u = get<0> (fic[t]);
        vertex v = get<1> (fic[t]);
        vertex w = get<2> (fic[t]);
        vertex x1 = get<3> (fic[t]);
        vertex x2 = get<4> (fic[t]);
        
        // Testing
        string tmp = to_string(u) + " " + to_string(v) + " " + to_string(w) + " " + to_string(x1) + " " + to_string(x2);
        //cout << "PoppedID : " << t << " , Popped k Value : " << K[t] << " , Frequency : " << umap[tmp] << endl;
        
        // Storing K value and Frequency for every vertex of the current clique
        
        cliqueVertices.push_back(u);
        cliqueVertices.push_back(v);
        cliqueVertices.push_back(w);
        cliqueVertices.push_back(x1);
        cliqueVertices.push_back(x2);
        
        saveVertexProperty(cliqueVertices, umapK, umapS, val, umap[tmp]);  // function body is in the "main.h" file
        
        // storing k and s values
        ksValues.push_back(make_tuple (val, umap[tmp]));
        
        cliqueVertices.clear();
        
        
        vertex cliqueID = umapID[tmp];
        vector<vertex> commonNeighbors;

        fiveWay (graph[u], graph[v], graph[w], graph[x1], graph[x2], commonNeighbors);
        
        
        /* HIERARCHY RELATED */
        if (hierarchy) {
            unassigned.clear();
            subcore sc (val);
            skeleton.push_back (sc);
        }
        
        for (auto y : commonNeighbors) {
            
            vector<couple> tempN;
            
            tempN.push_back ( make_tuple (graph[u].size(),u) );
            tempN.push_back ( make_tuple (graph[v].size(),v) );
            tempN.push_back ( make_tuple (graph[w].size(),w) );
            tempN.push_back ( make_tuple (graph[x1].size(),x1) );
            tempN.push_back ( make_tuple (graph[x2].size(),x2) );
            tempN.push_back ( make_tuple (graph[y].size(),y) );
            
            sort (tempN.begin(), tempN.end());
            
            vertex u1 = get<1>(tempN[0]);
            vertex u2 = get<1>(tempN[1]);
            vertex u3 = get<1>(tempN[2]);
            vertex u4 = get<1>(tempN[3]);
            vertex u5 = get<1>(tempN[4]);
            vertex u6 = get<1>(tempN[5]);
            
            tempN.clear();
            
            /* 6 clique : u1, u2, u3, u4, u5, u6
             There is six 5 cliques : (6 choose 5 = 6 combination)
             u1, u2, u3, u4, u5
             u1, u2, u3, u4, u6
             
             u1, u2, u3, u5, u6
             u1, u2, u4, u5, u6
             u1, u3, u4, u5, u6
             u2, u3, u4, u5, u6
             */
            
            string temp1 = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5); // u1, u2, u3, u4, u5
            vertex p = umapID[temp1];
            if (p == cliqueID)
                p = -2;
            
            string temp2 = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u6); // u1, u2, u3, u4, u6
            vertex q = umapID[temp2];
            if (q == cliqueID)
                q = -2;
            
            
            string temp3 = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u5) + " " + to_string(u6); // u1, u2, u3, u5, u6
            vertex r = umapID[temp3];
            if (r == cliqueID)
                r = -2;
           
            
           
            string temp4 = to_string(u1) + " " + to_string(u2) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6); // u1, u2, u4, u5, u6
            vertex s = umapID[temp4];
            if (s == cliqueID)
                s = -2;
            
            
            string temp5 = to_string(u1) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6);  // u1, u3, u4, u5, u6
            vertex t1 = umapID[temp5];
            if (t1 == cliqueID)
                t1 = -2;
            
            
            string temp6 = to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6);  // u2, u3, u4, u5, u6
            vertex t2 = umapID[temp6];
            if (t2 == cliqueID)
                t2 = -2;
            
            
            // p, q, r, s, t1, t2
            if(p==-2){
                p=q;
                q=r;
                r=s;
                s=t1;
                t1=t2;
            }
            else if(q==-2){
                q=r;
                r=s;
                s=t1;
                t1=t2;
            }
            else if(r==-2){
                r=s;
                s=t1;
                t1=t2;
            }
            else if(s==-2){
                s=t1;
                t1=t2;
            }
            else if(t1==-2){
                t1=t2;
            }
            
            if (K[p] == -1 && K[q] == -1 && K[r] == -1 && K[s] == -1 && K[t1] == -1 ) {
                
                if (nBucket.CurrentValue(p) > fc_t)
                    nBucket.DecVal(p);
                
                if (nBucket.CurrentValue(q) > fc_t)
                    nBucket.DecVal(q);
                
                if (nBucket.CurrentValue(r) > fc_t)
                    nBucket.DecVal(r);
                
                if (nBucket.CurrentValue(s) > fc_t)
                    nBucket.DecVal(s);
                
                if (nBucket.CurrentValue(t1) > fc_t)
                    nBucket.DecVal(t1);
            
            }
            else if (hierarchy) // boolean variable
                createSkeleton (t, {p, q, r, s, t1}, &nSubcores, K, skeleton, component, unassigned, relations);
        }
        if (hierarchy)
            updateUnassigned (t, component, &cid, relations, unassigned);
    }

    nBucket.Free();
    
    *max56 = fc_t; // fc_t is fc of the last popped 5-clique
    
    //cout << " value of maxK : " << fc_t << endl; // Testing
    
    const auto p2 = chrono::steady_clock::now();
    
    // Writing vertex statistics to a file
    
    string rst (rCliqueFilename);
    string outputFile1 = rst.substr(0, rst.find("_")) + "56" + "_vp.txt";
    string outputFile2 = rst.substr(0, rst.find("_")) + "56" + "_vs.txt";
    
    string outputFile3 = rst.substr(0, rst.find("_")) + "56" + "_k_S_values.txt";
    
    const auto vs1 = chrono::steady_clock::now();
    
    writeVertexProperty  (umapK, umapS, outputFile1);
    writeVertexStatistic (umapK, umapS, outputFile2);
    
    writeKSValues(ksValues, outputFile3);
    
    const auto vs2 = chrono::steady_clock::now();
    
    print_time (fp, "Vertex statistics computing time: ", vs2 - vs1);
    
    if (!hierarchy) {
        print_time (fp, "Only peeling time: ", p2 - p1);
        print_time (fp, "Total time: ", (p2 - p1) + (f2 - f1) + (t2 - t1));
    }
    else {
        
        print_time (fp, "Only peeling + on-the-fly hierarchy construction time: ", p2 - p1);
        
        const auto b1 = chrono::steady_clock::now();
        buildHierarchy (*max56, relations, skeleton, &nSubcores, nEdge, nVtx);  // update in large clique file
        const auto b2 = chrono::steady_clock::now();
        print_time (fp, "Building hierarchy time: ", b2 - b1);
        print_time (fp, "Total 5,6 nucleus decomposition time (excluding density computation): ", (p2 - p1) + (t2 - t1) + (b2 - b1)); // update in large clique file
        
        fprintf (fp, "# subcores: %d\t\t # subsubcores: %d\t\t |V|: %d\n", nSubcores, skeleton.size(), graph.size());
        
        const auto d1 = chrono::steady_clock::now();
        helpers hp (&fic); // update in large clique file
        presentNuclei (56, skeleton, component, graph, nEdge, hp, vfile, fp); // update in large clique file
        const auto d2 = chrono::steady_clock::now();
        
        print_time (fp, "Total 5,6 nucleus decomposition time: ", (p2 - p1) + (t2 - t1) + (b2 - b1) + (d2 - d1)); // update in large clique file
    }
}
