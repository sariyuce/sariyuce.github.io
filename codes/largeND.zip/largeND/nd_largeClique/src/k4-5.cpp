#include "main.h"
#define MAXLINE 1000000

inline void fourWay (vector<vertex>& x, vector<vertex>& y, vector<vertex>& z, vector<vertex>& t, vector<vertex>& commonNeighbors) {
    
    vertex i = 0, j = 0, k = 0, l = 0;
    
    while (i < x.size() && j < y.size() && k < z.size() && l < t.size()) {
       
        vertex a = x[i];
        vertex b = y[j];
        vertex c = z[k];
        vertex d = t[l];

        if (a == b && a == c && a == d) {
            commonNeighbors.push_back(a);
            i++; j++; k++; l++;
        }
        else {
            vertex m = max ({a, b, c, d});
            if (a != m)
                i++;
            if (b != m)
                j++;
            if (c != m)
                k++;
            if (d != m)
                l++;
        }
    }
}

// read all 4 cliques from the file and save each 4 clique according to "degree ordering" of the vertices in a 4 clique
void create_FourCliqueList(Graph& graph, char *rCliqueFilename, vector<vfour>& fc, vector<vertex>& xfc, unordered_map<string,int>& umap, unordered_map<string,int>& umapID){
    
    char* line = (char*) malloc (sizeof (char) * MAXLINE);
    FILE* fp = fopen(rCliqueFilename, "r");
    
    vertex u,v,w,x;
    
    vector<couple> temp;  // tuple <vertex, vertex> --> couple
    
    while (fgets(line, MAXLINE, fp)) {
        
        stringstream ss (line);
        ss >> u >> v >> w >> x;
        
        // ordering the vertices based on degree 
        temp.push_back ( make_tuple (graph[u].size(),u) );
        temp.push_back ( make_tuple (graph[v].size(),v) );
        temp.push_back ( make_tuple (graph[w].size(),w) );
        temp.push_back ( make_tuple (graph[x].size(),x) );
        
        sort (temp.begin(), temp.end());
        
        u = get<1>(temp[0]);
        v = get<1>(temp[1]);
        w = get<1>(temp[2]);
        x = get<1>(temp[3]);
        
        fc.push_back(make_tuple (u, v, w, x)); // deg(u) < deg(v) < deg(w) < deg(x). If deg is equal then vertex # is taken into consideration for breaking tie.
        
        temp.clear();
    
    }
    
    sort(fc.begin(), fc.end());

    // create "xfc" structure to track where the triangle changes in the list of four cliques
    xfc.push_back(0);
    
    for (int i = 1; i < fc.size(); i++){
        if( get<0>(fc[i]) == get<0>(fc[i-1]) && get<1>(fc[i]) == get<1>(fc[i-1]) && get<2>(fc[i]) == get<2>(fc[i-1]) )
           continue;
        else
           xfc.push_back(i);
    }
    
   // initial 5 clique count is 0 for every 4 clique and store the index (in "fc" vector) of all 4 cliques
    for (int i = 0; i < fc.size(); i++){
        
        string temp = to_string(get<0>(fc[i])) + " " + to_string(get<1>(fc[i])) + " " + to_string(get<2>(fc[i])) + " " + to_string(get<3>(fc[i]));
        
        umap[temp] = 0;
        umapID[temp] = i;
    }
}

// read five cliques from the file. Generate all 4 cliques (degree ordered) from a 5 clique and increment count for each 4 clique
void count_FourCliquesFrequency (Graph& graph, char *sCliqueFilename, unordered_map<string,int>& umap, unordered_map<string,int>& umapID, int* maX){
    
    char* line = (char*) malloc (sizeof (char) * MAXLINE);
    FILE* fp = fopen(sCliqueFilename, "r");
    
    vertex u,v,w,x,y;
    
    vector<couple> temp;  // tuple<vertex, vertex> --> couple
    
    while (fgets(line, MAXLINE, fp)) {
        
        stringstream ss (line);
        ss >> u >> v >> w >> x >> y;
        
        temp.push_back ( make_tuple (graph[u].size(),u) );
        temp.push_back ( make_tuple (graph[v].size(),v) );
        temp.push_back ( make_tuple (graph[w].size(),w) );
        temp.push_back ( make_tuple (graph[x].size(),x) );
        temp.push_back ( make_tuple (graph[y].size(),y) );
        
        sort (temp.begin(), temp.end());
        
        u = get<1>(temp[0]);
        v = get<1>(temp[1]);
        w = get<1>(temp[2]);
        x = get<1>(temp[3]);
        y = get<1>(temp[4]);
        
        temp.clear();
        
        /* 5 clique : u, v, w, x, y
         There is five 4 cliques : (5 choose 4 = 5 combination)
             u, v, w, x
             u, v, w, y
             u, v, x, y
             u, w, x, y
             v, w, x, y  */
        
        string temp1 = to_string(u) + " " + to_string(v) + " " + to_string(w) + " " + to_string(x);
        string temp2 = to_string(u) + " " + to_string(v) + " " + to_string(w) + " " + to_string(y);
        string temp3 = to_string(u) + " " + to_string(v) + " " + to_string(x) + " " + to_string(y);
        string temp4 = to_string(u) + " " + to_string(w) + " " + to_string(x) + " " + to_string(y);
        string temp5 = to_string(v) + " " + to_string(w) + " " + to_string(x) + " " + to_string(y);
        
        umap[temp1]++;
        umap[temp2]++;
        umap[temp3]++;
        umap[temp4]++;
        umap[temp5]++;
        
        int t = max ({ umap[temp1], umap[temp2], umap[temp3], umap[temp4], umap[temp5] });
        
        if ( t > *maX)
            *maX = t;
    }
}




void base_k45 (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max45, string vfile, FILE* fp) {
    
    const auto t1 = chrono::steady_clock::now();
    
    vertex nVtx = graph.size();
    
    vector<vp> el;
    vector<vertex> xel;
    Graph orderedGraph;
    
    // function from "main.h" file which will create an "Ordered Graph" from the input "Graph".  [graph ---> orderedGraph]
    createOrderedIndexEdges (graph, el, xel, orderedGraph);
    
    vector<vfour> fc;
    vector<vertex> xfc;
    
    // avg time complexity for insert, delete and update is O(1) for unordered_map
    unordered_map<string,int> umap;   // store the 5 clique frequency of all 4 cliques
    unordered_map<string,int> umapID; // every 4 clique is stored in a vector (fc). Every 4 clique has an index in the vector. umapID will store the index for all 4 cliques
    
    
    // function for creating the list of 4 cliques
    create_FourCliqueList (graph, rCliqueFilename, fc, xfc, umap, umapID);
    
    const auto t2 = chrono::steady_clock::now();
    print_time (fp, "4-Clique enumeration: ", t2 - t1);
    
    
    // 5-clique counting for each 4-clique
    
    const auto f1 = chrono::steady_clock::now();
    int max5cliqueCount = 0;
    
    // Function for counting 5 cliques for each 4 clique.
    count_FourCliquesFrequency (graph, sCliqueFilename, umap, umapID, &max5cliqueCount);
    
    
    fprintf (fp, "# 4-cliques: %lld\n", fc.size());
    
    const auto f2 = chrono::steady_clock::now();
    print_time (fp, "5-clique counting for every 4 clique: ", f2 - f1);
    
    
    //  ###  Peeling ####
    
   const auto p1 = chrono::steady_clock::now();
    
   K.resize (fc.size(), -1);
   Naive_Bucket nBucket;
   
   nBucket.Initialize (max5cliqueCount, fc.size());

   for (int i = 0; i < fc.size(); i++){
        
       string temp = to_string(get<0>(fc[i])) + " " + to_string(get<1>(fc[i])) + " " + to_string(get<2>(fc[i])) + " " + to_string(get<3>(fc[i]));
       
       if (umap[temp] > 0){
           nBucket.Insert ( umapID[temp], umap[temp] );
       }
       else{
           K[umapID[temp]] = 0;
       }
    }
    
    vertex fc_t = 0;
    
    umapVec umapK;
    umapVec umapS;
    vector<vertex> cliqueVertices;
    
    vector<couple> ksValues;       // store all Kappa and S values
    
    /* HIERARCHY RELATED */
    
    vertex cid;
    vector<subcore> skeleton;
    vector<vertex> component;
    vector<vp> relations;
    vector<vertex> unassigned;
    vertex nSubcores;
    
    if (hierarchy) {
        cid = 0;
        nSubcores = 0;
        component.resize (fc.size(), -1);
    }
        
        
    
    while (true) {
        edge t;
        edge val ;
        if (nBucket.PopMin(&t, &val)) // if the bucket is empty
            break;

        fc_t = K[t] = val;            // t is the id of the 4 clique. so need to find out the vertices for this 4 clique
        
        // The below 4 clique is included in a 5 clique which has another four 4 cliques. These 4 cliques are neighbor 4 cliques.
        vertex u = get<0> (fc[t]);
        vertex v = get<1> (fc[t]);
        vertex w = get<2> (fc[t]);
        vertex x = get<3> (fc[t]);
        
        // Testing
        string tmp = to_string(u) + " " + to_string(v) + " " + to_string(w) + " " + to_string(x);
        //cout << "PoppedID : " << t << " , Popped k Value : " << K[t] << " , Frequency : " << umap[tmp] << endl;
        
        // Storing K value and Frequency for every vertex of the current clique
        
        cliqueVertices.push_back(u);
        cliqueVertices.push_back(v);
        cliqueVertices.push_back(w);
        cliqueVertices.push_back(x);
        
        saveVertexProperty(cliqueVertices, umapK, umapS, val, umap[tmp]);  // function body is in the "main.h" file
        
        // storing k and s values
        ksValues.push_back(make_tuple (val, umap[tmp]));
  
        
        cliqueVertices.clear();
        
        vertex cliqueID = umapID[tmp];
        vector<vertex> commonNeighbors;

        fourWay (graph[u], graph[v], graph[w], graph[x], commonNeighbors);
        
        /* HIERARCHY RELATED */
        if (hierarchy) {
            unassigned.clear();
            subcore sc (val);
            skeleton.push_back (sc);
        }
            
        for (auto y : commonNeighbors) {
            
            vector<couple> tempN;
            
            tempN.push_back ( make_tuple (graph[u].size(),u) );
            tempN.push_back ( make_tuple (graph[v].size(),v) );
            tempN.push_back ( make_tuple (graph[w].size(),w) );
            tempN.push_back ( make_tuple (graph[x].size(),x) );
            tempN.push_back ( make_tuple (graph[y].size(),y) );
            
            sort (tempN.begin(), tempN.end());
            
            vertex uu = get<1>(tempN[0]);
            vertex vv = get<1>(tempN[1]);
            vertex ww = get<1>(tempN[2]);
            vertex xx = get<1>(tempN[3]);
            vertex yy = get<1>(tempN[4]);
            
            tempN.clear();
            
            string temp1 = to_string(uu) + " " + to_string(vv) + " " + to_string(ww) + " " + to_string(yy);  // Neighbor 4 clique : u,v,w,y
            vertex p = umapID[temp1];
            if (p == cliqueID)
                p = -2;
            
            string temp2 = to_string(uu) + " " + to_string(vv) + " " + to_string(xx) + " " + to_string(yy);  // Neighbor 4 clique : u,v,x,y
            vertex q = umapID[temp2];
            if (q == cliqueID)
                q = -2;
            
            string temp3 = to_string(uu) + " " + to_string(ww) + " " + to_string(xx) + " " + to_string(yy);  // Neighbor 4 clique : u,w,x,y
            vertex r = umapID[temp3];
            if (r == cliqueID)
                r = -2;
           
            string temp4 = to_string(vv) + " " + to_string(ww) + " " + to_string(xx) + " " + to_string(yy);  // Neighbor 4 clique : v,w,x,y
            vertex s = umapID[temp4];
            if (s == cliqueID)
                s = -2;
            
            string temp5 = to_string(uu) + " " + to_string(vv) + " " + to_string(ww) + " " + to_string(xx);  // Neighbor 4 clique : u,v,w,x
            vertex t1 = umapID[temp5];
            if (t1 == cliqueID)
                t1 = -2;
            
            if(p==-2){
                p=q;
                q=r;
                r=s;
                s=t1;
            }
            else if(q==-2){
                q=r;
                r=s;
                s=t1;
            }
            else if(r==-2){
                r=s;
                s=t1;
            }
            else if(s==-2){
                s=t1;
            }
            
            if (K[p] == -1 && K[q] == -1 && K[r] == -1 && K[s] == -1 ) {
                
                if (nBucket.CurrentValue(p) > fc_t)
                    nBucket.DecVal(p);
                
                if (nBucket.CurrentValue(q) > fc_t)
                    nBucket.DecVal(q);
                
                if (nBucket.CurrentValue(r) > fc_t)
                    nBucket.DecVal(r);
                
                if (nBucket.CurrentValue(s) > fc_t)
                    nBucket.DecVal(s);
            
            }
            else if (hierarchy) // boolean variable
                createSkeleton (t, {p, q, r, s}, &nSubcores, K, skeleton, component, unassigned, relations);
        }
        if (hierarchy)
            updateUnassigned (t, component, &cid, relations, unassigned);
        
    }

    nBucket.Free();
    
    *max45 = fc_t; // fc_t is fc of the last popped 4-clique
    
    //cout << " value of maxK : " << fc_t << endl; // Testing
    const auto p2 = chrono::steady_clock::now();
    
    
    // Writing vertex statistics to a file
    
    string rst (rCliqueFilename);
    string outputFile1 = rst.substr(0, rst.find("_")) + "45" + "_vp.txt";
    string outputFile2 = rst.substr(0, rst.find("_")) + "45" + "_vs.txt";
    
    string outputFile3 = rst.substr(0, rst.find("_")) + "45" + "_k_S_values.txt";

    const auto vs1 = chrono::steady_clock::now();
    
    writeVertexProperty  (umapK, umapS, outputFile1);
    writeVertexStatistic (umapK, umapS, outputFile2);
    
    writeKSValues(ksValues, outputFile3);
    
    const auto vs2 = chrono::steady_clock::now();
    
    print_time (fp, "Vertex statistics computing time: ", vs2 - vs1);
    
    if (!hierarchy) {
        print_time (fp, "Only peeling time: ", p2 - p1);
        print_time (fp, "Total time: ", (p2 - p1) + (f2 - f1) + (t2 - t1));
    }
    else {
        print_time (fp, "Only peeling + on-the-fly hierarchy construction time: ", p2 - p1);
        const auto b1 = chrono::steady_clock::now();
        buildHierarchy (*max45, relations, skeleton, &nSubcores, nEdge, nVtx);
        const auto b2 = chrono::steady_clock::now();
        
        print_time (fp, "Building hierarchy time: ", b2 - b1);
        print_time (fp, "Total 4,5 nucleus decomposition time (excluding density computation): ", (p2 - p1) + (t2 - t1) + (b2 - b1));
        
        fprintf (fp, "# subcores: %d\t\t # subsubcores: %d\t\t |V|: %d\n", nSubcores, skeleton.size(), graph.size());
        
        const auto d1 = chrono::steady_clock::now();
        helpers hp (&fc);
        presentNuclei (45, skeleton, component, graph, nEdge, hp, vfile, fp);
        const auto d2 = chrono::steady_clock::now();
        
        print_time (fp, "Total 4,5 nucleus decomposition time: ", (p2 - p1) + (t2 - t1) + (b2 - b1) + (d2 - d1));
    }

}
