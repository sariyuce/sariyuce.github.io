#include "main.h"

int main (int argc, char *argv[]) {
    
	const auto t1 = chrono::steady_clock::now();
    
    /*
        Checking and processing command line arguments
        ./nucleus <graph> <rCliqueFile> <sCliqueFile> <algorithm> <hierarchy?>
     */
    
    if (argc != 6){
        fprintf(stderr, "usage of : %s "
                "\n <inputFilename>"
                "\n <rCliqueFilename>"
                "\n <sCliqueFilename>"
                "\n <nucleus type: rs>"
                "\n <hierarchy?: YES or NO>\n", argv[0]);
        exit(1);
    }
    
    char *filename = argv[1];         // input file pointer
    char *rCliqueFilename = argv[2];  // r clique file pointer
    char *sCliqueFilename = argv[3];  // s clique file pointer , s = r+1
    
    string tmp(argv[1]);             // Input filename
    string nd(argv[4]);              // Algorithm for nucleus decomposition
    string hrc (argv[5]);            // Hierarchy flag (YES/NO)
    
    // checking if the algo is valid for nucleus decomposition (nd)
    if (!(nd == "12" || nd == "13" || nd == "14" || nd == "23" || nd == "24" || nd == "34" || nd == "45" || nd == "56" || nd == "67" || nd == "78" || nd == "89" || nd == "910" )) {
        printf ("Invalid algorithm, options are 12, 13, 14, 23, 24, 34, 45, 56, 67, 78, 89 and 910\n");
        exit(1);
    }
    
    string gname = tmp.substr (tmp.find_last_of("/") + 1); // if tmp = a/b/c then gname = c
    string vfile = gname + "_" + nd;
    string out_file;
    
    bool hierarchy = (hrc == "YES" ? true : false);
    
    if (hierarchy)
        out_file = vfile + "_Hierarchy";
    else
        out_file = vfile + "_K";

    
	// read the graph, give "SORTED EDGES" in graph
    
	edge nEdge = 0; // typedef int edge in "main.h". 
	Graph graph;    // typedef vector<vector<vertex> Graph in "main.h". "Graph" will contain the "Adjacecncy list" of the input graph
    
    
    printf("Calling Function readGraph() for reading the input graph file \n"); // Testing
    
    // template function in "graph.cpp" file for reading the input graph into the variable "graph"
    
	readGraph<vertex,edge> (filename, graph, &nEdge);  // Prototype of this function is included in "main.h" file and  function body is in "graph.cpp" file
    
    
	FILE* fp = fopen (out_file.c_str(), "w");

	vertex maxK;     // maximum K value in the graph
	vector<vertex> K;
    
//    printf("Calling algo for nd \n"); // Testing
    
    int algo = stoi(nd);
    
    switch (algo)
    {
        // // Prototype of all these functions are in "main.h" file
        case 12:
            base_kcore (graph, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 13:
            base_k13 (graph, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 14:
            base_k14 (graph, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 23:
            base_ktruss (graph, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 24:
            base_k24 (graph, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 34:
            //base_k34 (graph, hierarchy, nEdge, K, &maxK, vfile, fp);    // for old k3-4.cpp
            base_k34 (graph, rCliqueFilename, sCliqueFilename, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 45:
            base_k45 (graph, rCliqueFilename, sCliqueFilename, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 56:
            base_k56 (graph, rCliqueFilename, sCliqueFilename, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 67:
            base_k67 (graph, rCliqueFilename, sCliqueFilename, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 78:
            base_k78 (graph, rCliqueFilename, sCliqueFilename, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 89:
            base_k89 (graph, rCliqueFilename, sCliqueFilename, hierarchy, nEdge, K, &maxK, vfile, fp);
            break;
        case 910:
            base_k910 (graph, rCliqueFilename, sCliqueFilename, hierarchy, nEdge, K, &maxK, vfile, fp);  
            break;
        default:
            printf("Inavlid algorithm choice \n");
            break;
    }

    
    
#ifdef DUMP_K
	string kfile = vfile + "_K_values";
	FILE* kf = fopen (kfile.c_str(), "w");
	for (vertex i = 0; i < K.size(); i++)
		fprintf (kf, "%lld\n", K[i]);
	fclose (kf);
#endif

	const auto t2 = chrono::steady_clock::now();
    
	printf ("%s - |V|: %d \t |E|: %d \t maxK for %s-nucleus: %d \n", gname.c_str(), graph.size(), nEdge, nd.c_str(), maxK);
    
	print_time (fp, "End-to-end Time: ", t2 - t1);
    
	fclose (fp);

	return 0;
}
