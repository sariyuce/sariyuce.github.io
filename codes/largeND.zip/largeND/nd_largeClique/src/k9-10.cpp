#include "main.h"
#define MAXLINE 1000000

inline void nineWay (vector<vertex>& x, vector<vertex>& y, vector<vertex>& z, vector<vertex>& t1, vector<vertex>& t2, vector<vertex>& t3, vector<vertex>& t4, vector<vertex>& t5, vector<vertex>& t6, vector<vertex>& commonNeighbors) {
    
    vertex i = 0, j = 0, k = 0, l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
    
    while (i < x.size() && j < y.size() && k < z.size() && l1 < t1.size() && l2 < t2.size() && l3 < t3.size() && l4 < t4.size() && l5 < t5.size() && l6 < t6.size()) {
       
        vertex a = x[i];
        vertex b = y[j];
        vertex c = z[k];
        vertex d = t1[l1];
        vertex e = t2[l2];
        vertex f = t3[l3];
        vertex g = t4[l4];
        vertex h = t5[l5];
        vertex h1 = t6[l6];

        if (a == b && a == c && a == d && a == e && a == f && a == g && a == h && a == h1) {
            commonNeighbors.push_back(a);
            i++; j++; k++; l1++; l2++; l3++; l4++; l5++; l6++;
        }
        else {
            vertex m = max ({a, b, c, d, e, f, g, h, h1});
            if (a != m)
                i++;
            if (b != m)
                j++;
            if (c != m)
                k++;
            if (d != m)
                l1++;
            if (e != m)
                l2++;
            if (f != m)
                l3++;
            if (g != m)
                l4++;
            if (h != m)
                l5++;
            if (h1 != m)
                l6++;
        }
    }
}

// read all 9-cliques from the file and save each 9-clique according to "degree ordering" of the vertices in a 9-clique

void create_NineCliqueList(Graph& graph, char *rCliqueFilename, vector<vnine>& nc, vector<vertex>& xnc, unordered_map<string,int>& umap, unordered_map<string,int>& umapID){
    
    char* line = (char*) malloc (sizeof (char) * MAXLINE);
    FILE* fp = fopen(rCliqueFilename, "r");
    
    vertex u,v,w,x,y,z,zz,zzz,zzzz;
    vector<couple> temp;  // tuple <vertex, vertex> --> couple

    while (fgets(line, MAXLINE, fp)) {
        
        stringstream ss (line);
        ss >> u >> v >> w >> x >> y >> z >> zz >> zzz >> zzzz;
        
        // ordering the vertices based on degree 
        temp.push_back ( make_tuple (graph[u].size(),u) );
        temp.push_back ( make_tuple (graph[v].size(),v) );
        temp.push_back ( make_tuple (graph[w].size(),w) );
        temp.push_back ( make_tuple (graph[x].size(),x) );
        temp.push_back ( make_tuple (graph[y].size(),y) );
        temp.push_back ( make_tuple (graph[z].size(),z) );
        temp.push_back ( make_tuple (graph[zz].size(),zz) );
        temp.push_back ( make_tuple (graph[zzz].size(),zzz) );
        temp.push_back ( make_tuple (graph[zzzz].size(),zzzz) );
        
        sort (temp.begin(), temp.end());
        
        u = get<1>(temp[0]);
        v = get<1>(temp[1]);
        w = get<1>(temp[2]);
        x = get<1>(temp[3]);
        y = get<1>(temp[4]);
        z = get<1>(temp[5]);
        zz = get<1>(temp[6]);
        zzz = get<1>(temp[7]);
        zzzz = get<1>(temp[8]);
        
        nc.push_back( make_tuple (u, v, w, x, y, z, zz, zzz, zzzz)); // deg(u) < deg(v) < deg(w) < deg(x) < deg(y) < deg(z) < deg(zz) < deg(zzz) < deg(zzzz).
        temp.clear();
    
    }
    
    sort(nc.begin(), nc.end());

    // create "xnc" structure to track where the 8-clique changes in the list of 9-cliques
    
    xnc.push_back(0);
    
    for (int i = 1; i < nc.size(); i++){
         if( get<0>(nc[i]) == get<0>(nc[i-1]) && get<1>(nc[i]) == get<1>(nc[i-1]) && get<2>(nc[i]) == get<2>(nc[i-1]) && get<3>(nc[i]) == get<3>(nc[i-1]) && get<4>(nc[i]) == get<4>(nc[i-1]) && get<5>(nc[i]) == get<5>(nc[i-1]) && get<6>(nc[i]) == get<6>(nc[i-1]) && get<7>(nc[i]) == get<7>(nc[i-1]))
            continue;
         else
            xnc.push_back(i);
    }

   // initial 10-clique count is 0 for every 9-clique and store the index (in "nc" vector) of all 9-cliques
    for (int i = 0; i < nc.size(); i++){
        
        string temp = to_string(get<0>(nc[i])) + " " + to_string(get<1>(nc[i])) + " " + to_string(get<2>(nc[i])) + " " + to_string(get<3>(nc[i])) + " " + to_string(get<4>(nc[i])) + " " + to_string(get<5>(nc[i])) + " " + to_string(get<6>(nc[i])) + " " + to_string(get<7>(nc[i])) + " " + to_string(get<8>(nc[i]));
        
        umap[temp] = 0;
        umapID[temp] = i;
    }
}


// read 10-cliques from the file. Generate all 9-cliques (degree ordered) from a 10-clique and increment 10-clique count for each 9-clique

void count_NineCliquesFrequency (Graph& graph, char *sCliqueFilename, unordered_map<string,int>& umap, unordered_map<string,int>& umapID, int* maX){
    
    char* line = (char*) malloc (sizeof (char) * MAXLINE);
    FILE* fp = fopen(sCliqueFilename, "r");
    
    vertex u1, u2, u3, u4, u5, u6, u7, u8, u9, u10;
    
    vector<couple> temp;  // tuple<vertex, vertex> --> couple
    
    while (fgets(line, MAXLINE, fp)) {
        
        stringstream ss (line);
        ss >> u1 >> u2 >> u3 >> u4 >> u5 >> u6 >> u7 >> u8 >> u9 >> u10;
        
        temp.push_back ( make_tuple (graph[u1].size(),u1) );
        temp.push_back ( make_tuple (graph[u2].size(),u2) );
        temp.push_back ( make_tuple (graph[u3].size(),u3) );
        temp.push_back ( make_tuple (graph[u4].size(),u4) );
        temp.push_back ( make_tuple (graph[u5].size(),u5) );
        temp.push_back ( make_tuple (graph[u6].size(),u6) );
        temp.push_back ( make_tuple (graph[u7].size(),u7) );
        temp.push_back ( make_tuple (graph[u8].size(),u8) );
        temp.push_back ( make_tuple (graph[u9].size(),u9) );
        temp.push_back ( make_tuple (graph[u10].size(),u10) );
        
        sort (temp.begin(), temp.end());
        
        u1 = get<1>(temp[0]);
        u2 = get<1>(temp[1]);
        u3 = get<1>(temp[2]);
        u4 = get<1>(temp[3]);
        u5 = get<1>(temp[4]);
        u6 = get<1>(temp[5]);
        u7 = get<1>(temp[6]);
        u8 = get<1>(temp[7]);
        u9 = get<1>(temp[8]);
        u10 = get<1>(temp[9]);
        
        temp.clear();
        
        /* 10 clique : u1, u2, u3, u4, u5, u6, u7, u8, u9, u10

         There are 10 "9-cliques" : (10 choose 9 = 10 combination)
         
         u1, u2, u3, u4, u5, u6, u7, u8, u9  -- u10
         u1, u2, u3, u4, u5, u6, u7, u8, u10 -- u9
         u1, u2, u3, u4, u5, u6, u7, u9, u10 -- u8
         u1, u2, u3, u4, u5, u6, u8, u9, u10 -- u7
         u1, u2, u3, u4, u5, u7, u8, u9, u10 -- u6
         u1, u2, u3, u4, u6, u7, u8, u9, u10 -- u5
         u1, u2, u3, u5, u6, u7, u8, u9, u10 -- u4
         u1, u2, u4, u5, u6, u7, u8, u9, u10 -- u3
         u1, u3, u4, u5, u6, u7, u8, u9, u10 -- u2
         u2, u3, u4, u5, u6, u7, u8, u9, u10 -- u1   */
        
        string temp1  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9);
        string temp2  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u10);
        string temp3  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u9) + " " + to_string(u10);
        string temp4  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
        string temp5  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
        string temp6  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
        string temp7  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
        string temp8  = to_string(u1) + " " + to_string(u2) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
        string temp9  = to_string(u1) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
        string temp10 = to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
        
        umap[temp1]++;
        umap[temp2]++;
        umap[temp3]++;
        umap[temp4]++;
        umap[temp5]++;
        umap[temp6]++;
        umap[temp7]++;
        umap[temp8]++;
        umap[temp9]++;
        umap[temp10]++;
        
        int t = max ({ umap[temp1], umap[temp2], umap[temp3], umap[temp4], umap[temp5], umap[temp6], umap[temp7], umap[temp8], umap[temp9], umap[temp10] });
        
        if ( t > *maX)
            *maX = t;
    }
}


void base_k910 (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max910, string vfile, FILE* fp) {
    
    const auto t1 = chrono::steady_clock::now();
    
    vertex nVtx = graph.size();
    
    vector<vp> el;
    vector<vertex> xel;
    Graph orderedGraph;
    
    // function from "main.h" file which will create an "Ordered Graph" from the input "Graph".  [graph ---> orderedGraph]
    createOrderedIndexEdges (graph, el, xel, orderedGraph);
    
    vector<vnine> nc;
    vector<vertex> xnc;
    
    // avg time complexity for insert, delete and update is O(1) for unordered_map
    unordered_map<string,int> umap;   // store the 10-clique frequency of all 9-cliques
    unordered_map<string,int> umapID; // every 9-clique is stored in a vector (nc) and has an index in the vector. umapID will store the index for all 9-cliques
    
    
    // function for creating the list of 9-cliques
    create_NineCliqueList(graph, rCliqueFilename, nc, xnc, umap, umapID);
    
    const auto t2 = chrono::steady_clock::now();
    
    print_time (fp, "9-Clique enumeration: ", t2 - t1);
    
    
    
    // 10-clique counting for each 9-clique
    
    const auto f1 = chrono::steady_clock::now();
    int max10cliqueCount = 0;
    
    // Function for counting 10-cliques for each 9-clique.
    count_NineCliquesFrequency (graph, sCliqueFilename, umap, umapID, &max10cliqueCount);
    
    fprintf (fp, "# 9-cliques: %lld\n", nc.size());
    
    const auto f2 = chrono::steady_clock::now();
    
    print_time (fp, "10-clique counting for every 9-clique: ", f2 - f1);
    
    
    //  ###  Peeling ####
    
   const auto p1 = chrono::steady_clock::now();
    
   K.resize (nc.size(), -1);
   Naive_Bucket nBucket;
   
   nBucket.Initialize (max10cliqueCount, nc.size());

   for (int i = 0; i < nc.size(); i++){
       
       string temp = to_string(get<0>(nc[i])) + " " + to_string(get<1>(nc[i])) + " " + to_string(get<2>(nc[i])) + " " + to_string(get<3>(nc[i])) + " " + to_string(get<4>(nc[i])) + " " + to_string(get<5>(nc[i])) + " " + to_string(get<6>(nc[i])) + " " + to_string(get<7>(nc[i])) + " " + to_string(get<8>(nc[i]));
       
       if (umap[temp] > 0){
           nBucket.Insert ( umapID[temp], umap[temp] );
       }
       else{
           K[umapID[temp]] = 0;
       }
    }
    
    vertex fc_t = 0;
    
    umapVec umapK;
    umapVec umapS;
    vector<vertex> cliqueVertices;
    
    vector<couple> ksValues;       // store all Kappa and S values
    
    /* HIERARCHY RELATED */
    
    vertex cid;
    vector<subcore> skeleton;
    vector<vertex> component;
    vector<vp> relations;
    vector<vertex> unassigned;
    vertex nSubcores;
    
    if (hierarchy) {
        cid = 0;
        nSubcores = 0;
        component.resize (nc.size(), -1);
    }
    
    
    while (true) {
        edge t;
        edge val ;
        if (nBucket.PopMin(&t, &val)) // if the bucket is empty
            break;

        fc_t = K[t] = val;  // "t" is the id of the 9-clique. So, need to find out the vertices for this 9-clique
        
        // The below 9-clique is included in a 10-clique which has another nine 9-cliques. These 9-cliques are neighbor 9-cliques.
        
        vertex u  = get<0> (nc[t]);
        vertex v  = get<1> (nc[t]);
        vertex w  = get<2> (nc[t]);
        vertex x1 = get<3> (nc[t]);
        vertex x2 = get<4> (nc[t]);
        vertex x3 = get<5> (nc[t]);
        vertex x4 = get<6> (nc[t]);
        vertex x5 = get<7> (nc[t]);
        vertex x6 = get<8> (nc[t]);
        
        // Testing
        string tmp = to_string(u) + " " + to_string(v) + " " + to_string(w) + " " + to_string(x1) + " " + to_string(x2) + " " + to_string(x3) + " " + to_string(x4) + " " + to_string(x5) + " " + to_string(x6);
        //cout << "PoppedID : " << t << " , Popped k Value : " << K[t] << " , Frequency : " << umap[tmp] << endl;
        
        // Storing K value and Frequency for every vertex of the current clique
        
        cliqueVertices.push_back(u);
        cliqueVertices.push_back(v);
        cliqueVertices.push_back(w);
        cliqueVertices.push_back(x1);
        cliqueVertices.push_back(x2);
        cliqueVertices.push_back(x3);
        cliqueVertices.push_back(x4);
        cliqueVertices.push_back(x5);
        cliqueVertices.push_back(x6);
        
        saveVertexProperty(cliqueVertices, umapK, umapS, val, umap[tmp]);  // function body is in the "main.h" file
        
        // storing k and s values
        ksValues.push_back(make_tuple (val, umap[tmp]));
        
        cliqueVertices.clear();
        
        vertex cliqueID = umapID[tmp];
        vector<vertex> commonNeighbors;

        nineWay (graph[u], graph[v], graph[w], graph[x1], graph[x2], graph[x3], graph[x4], graph[x5], graph[x6], commonNeighbors);
        
        
        /* HIERARCHY RELATED */
        if (hierarchy) {
            unassigned.clear();
            subcore sc (val);
            skeleton.push_back (sc);
        }
        
        for (auto y : commonNeighbors) {
            
            vector<couple> tempN;
            
            tempN.push_back ( make_tuple (graph[u].size(),u) );
            tempN.push_back ( make_tuple (graph[v].size(),v) );
            tempN.push_back ( make_tuple (graph[w].size(),w) );
            tempN.push_back ( make_tuple (graph[x1].size(),x1) );
            tempN.push_back ( make_tuple (graph[x2].size(),x2) );
            tempN.push_back ( make_tuple (graph[x3].size(),x3) );
            tempN.push_back ( make_tuple (graph[x4].size(),x4) );
            tempN.push_back ( make_tuple (graph[x5].size(),x5) );
            tempN.push_back ( make_tuple (graph[x6].size(),x6) );
            tempN.push_back ( make_tuple (graph[y].size(),y) );
            
            sort (tempN.begin(), tempN.end());
            
            vertex u1  = get<1>(tempN[0]);
            vertex u2  = get<1>(tempN[1]);
            vertex u3  = get<1>(tempN[2]);
            vertex u4  = get<1>(tempN[3]);
            vertex u5  = get<1>(tempN[4]);
            vertex u6  = get<1>(tempN[5]);
            vertex u7  = get<1>(tempN[6]);
            vertex u8  = get<1>(tempN[7]);
            vertex u9  = get<1>(tempN[8]);
            vertex u10 = get<1>(tempN[9]);
            
            tempN.clear();
            
            /* 10 clique : u1, u2, u3, u4, u5, u6, u7, u8, u9, u10
             
             There are 10 "9-cliques" : (10 choose 9 = 10 combination)
             
             u1, u2, u3, u4, u5, u6, u7, u8, u9  -- u10
             u1, u2, u3, u4, u5, u6, u7, u8, u10 -- u9
             u1, u2, u3, u4, u5, u6, u7, u9, u10 -- u8
             u1, u2, u3, u4, u5, u6, u8, u9, u10 -- u7
             u1, u2, u3, u4, u5, u7, u8, u9, u10 -- u6
             u1, u2, u3, u4, u6, u7, u8, u9, u10 -- u5
             u1, u2, u3, u5, u6, u7, u8, u9, u10 -- u4
             u1, u2, u4, u5, u6, u7, u8, u9, u10 -- u3
             u1, u3, u4, u5, u6, u7, u8, u9, u10 -- u2
             u2, u3, u4, u5, u6, u7, u8, u9, u10 -- u1   */
            
            string temp1  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9);
            vertex p = umapID[temp1];
            if (p == cliqueID)
                p = -2;
        
            
            string temp2  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u10);
            vertex q = umapID[temp2];
            if (q == cliqueID)
                q = -2;
            
            
            string temp3  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u9) + " " + to_string(u10);
            vertex r = umapID[temp3];
            if (r == cliqueID)
                r = -2;
           

            string temp4  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
            vertex s = umapID[temp4];
            if (s == cliqueID)
                s = -2;
            
            
            string temp5  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
            vertex t1 = umapID[temp5];
            if (t1 == cliqueID)
                t1 = -2;

            
            string temp6  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
            vertex t2 = umapID[temp6];
            if (t2 == cliqueID)
                t2 = -2;
            
            string temp7  = to_string(u1) + " " + to_string(u2) + " " + to_string(u3) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
            vertex t3 = umapID[temp7];
            if (t3 == cliqueID)
                t3 = -2;
            
            
            string temp8  = to_string(u1) + " " + to_string(u2) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
            vertex t4 = umapID[temp8];
            if (t4 == cliqueID)
                t4 = -2;
            
            
            
            string temp9  = to_string(u1) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
            vertex t5 = umapID[temp9];
            if (t5 == cliqueID)
                t5 = -2;
            
        
            string temp10 = to_string(u2) + " " + to_string(u3) + " " + to_string(u4) + " " + to_string(u5) + " " + to_string(u6) + " " + to_string(u7) + " " + to_string(u8) + " " + to_string(u9) + " " + to_string(u10);
            vertex t6 = umapID[temp10];
            if (t6 == cliqueID)
                t6 = -2;
            

            // p, q, r, s, t1, t2, t3, t4, t5, t6
            
            if(p==-2){
                p=q;
                q=r;
                r=s;
                s=t1;
                t1=t2;
                t2=t3;
                t3=t4;
                t4=t5;
                t5=t6;
            }
            else if(q==-2){
                q=r;
                r=s;
                s=t1;
                t1=t2;
                t2=t3;
                t3=t4;
                t4=t5;
                t5=t6;
            }
            else if(r==-2){
                r=s;
                s=t1;
                t1=t2;
                t2=t3;
                t3=t4;
                t4=t5;
                t5=t6;
            }
            else if(s==-2){
                s=t1;
                t1=t2;
                t2=t3;
                t3=t4;
                t4=t5;
                t5=t6;
            }
            else if(t1==-2){
                t1=t2;
                t2=t3;
                t3=t4;
                t4=t5;
                t5=t6;
            }
            else if(t2==-2){
                t2=t3;
                t3=t4;
                t4=t5;
                t5=t6;
            }
            else if(t3==-2){
                t3=t4;
                t4=t5;
                t5=t6;
            }
            else if(t4==-2){
                t4=t5;
                t5=t6;
            }
            else if(t5==-2){
                t5=t6;
            }
            
            if (K[p] == -1 && K[q] == -1 && K[r] == -1 && K[s] == -1 && K[t1] == -1 && K[t2] == -1 && K[t3] == -1 && K[t4] == -1 && K[t5] == -1) {
                
                if (nBucket.CurrentValue(p) > fc_t)
                    nBucket.DecVal(p);
                
                if (nBucket.CurrentValue(q) > fc_t)
                    nBucket.DecVal(q);
                
                if (nBucket.CurrentValue(r) > fc_t)
                    nBucket.DecVal(r);
                
                if (nBucket.CurrentValue(s) > fc_t)
                    nBucket.DecVal(s);
                
                if (nBucket.CurrentValue(t1) > fc_t)
                    nBucket.DecVal(t1);
                
                if (nBucket.CurrentValue(t2) > fc_t)
                    nBucket.DecVal(t2);
                
                if (nBucket.CurrentValue(t3) > fc_t)
                    nBucket.DecVal(t3);
                
                if (nBucket.CurrentValue(t4) > fc_t)
                    nBucket.DecVal(t4);
                
                if (nBucket.CurrentValue(t5) > fc_t)
                    nBucket.DecVal(t5);
            
            }
            else if (hierarchy) // boolean variable
                createSkeleton (t, {p, q, r, s, t1, t2, t3, t4, t5}, &nSubcores, K, skeleton, component, unassigned, relations);
        }
        if (hierarchy)
            updateUnassigned (t, component, &cid, relations, unassigned);
    }

    nBucket.Free();
    
    *max910 = fc_t;
    
    //cout << " value of maxK : " << fc_t << endl; // Testing
    
    const auto p2 = chrono::steady_clock::now();
    
    // Writing vertex statistics to a file
    
    string rst (rCliqueFilename);
    string outputFile1 = rst.substr(0, rst.find("_")) + "910" + "_vp.txt";
    string outputFile2 = rst.substr(0, rst.find("_")) + "910" + "_vs.txt";
    
    string outputFile3 = rst.substr(0, rst.find("_")) + "910" + "_k_S_values.txt";
    
    
    const auto vs1 = chrono::steady_clock::now();
    
    writeVertexProperty  (umapK, umapS, outputFile1);
    writeVertexStatistic (umapK, umapS, outputFile2);
    
    writeKSValues(ksValues, outputFile3);
    
    const auto vs2 = chrono::steady_clock::now();
    
    print_time (fp, "Vertex statistics computing time: ", vs2 - vs1);
    
    if (!hierarchy) {
        print_time (fp, "Only peeling time: ", p2 - p1);
        print_time (fp, "Total time: ", (p2 - p1) + (f2 - f1) + (t2 - t1));
    }
    else {
        
        print_time (fp, "Only peeling + on-the-fly hierarchy construction time: ", p2 - p1);
        
        const auto b1 = chrono::steady_clock::now();
        buildHierarchy (*max910, relations, skeleton, &nSubcores, nEdge, nVtx);  // update in large clique file
        const auto b2 = chrono::steady_clock::now();
        print_time (fp, "Building hierarchy time: ", b2 - b1);
        print_time (fp, "Total 9,10 nucleus decomposition time (excluding density computation): ", (p2 - p1) + (t2 - t1) + (b2 - b1)); // update in large clique file
        
        fprintf (fp, "# subcores: %d\t\t # subsubcores: %d\t\t |V|: %d\n", nSubcores, skeleton.size(), graph.size());
        
        const auto d1 = chrono::steady_clock::now();
        helpers hp (&nc);                                                     // update in large clique file
        presentNuclei (910, skeleton, component, graph, nEdge, hp, vfile, fp); // update in large clique file
        const auto d2 = chrono::steady_clock::now();
        
        print_time (fp, "Total 9,10 nucleus decomposition time: ", (p2 - p1) + (t2 - t1) + (b2 - b1) + (d2 - d1)); // update in large clique file
    }
}
