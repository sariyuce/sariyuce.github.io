#include <iostream>
#include <sstream>
#include <fstream>

#include <queue>
#include <stack>
#include <vector>
#include <set>
#include <map>
#include <unordered_map>

#include <algorithm>
#include <utility>
#include <string>
#include <initializer_list>

#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <random>
#include <chrono>
#include <sys/stat.h>

#include "bucket.h"           // Custom header file

using namespace std;

#define LOWERBOUND 0
#define UPPERBOUND 500       // Compute densities of subgraphs with at most this size, set to INT_MAX to compute all -- takes a lot of time
#define THRESHOLD 0.0
#define PRIME 251231         // For hash function

typedef long long lol;

// vertices and edges are integer.
// If the graph is very large then vertex id won't be fit in integer data type. In that case just change the data type of vertex and edges in these two lines below.

typedef int vertex;
typedef int edge;

typedef unordered_multimap <int, int> mmap;

typedef pair  <vertex, vertex> vp;
typedef tuple <vertex, vertex, vertex> vt;

typedef tuple <vertex, vertex> couple;                                                         // couple --> for storing a 2 clique (Edge)
typedef tuple <vertex, vertex, vertex> triple;                                                 // triple --> for storing a 3 clique (Triangle)

typedef tuple <vertex, vertex, vertex, vertex> vfour;                                          // vfour  --> for storing a 4 clique
typedef tuple <vertex, vertex, vertex, vertex, vertex> vfive;                                  // vfive  --> for storing a 5 clique
typedef tuple <vertex, vertex, vertex, vertex, vertex, vertex> vsix;                           // vsix   --> for storing a 6 clique
typedef tuple <vertex, vertex, vertex, vertex, vertex, vertex, vertex> vseven;                 // vseven --> for storing a 7 clique
typedef tuple <vertex, vertex, vertex, vertex, vertex, vertex, vertex, vertex> veight;         // veight --> for storing a 8 clique
typedef tuple <vertex, vertex, vertex, vertex, vertex, vertex, vertex, vertex, vertex> vnine;  // vnine  --> for storing a 9 clique


typedef vector < vector<vertex> > Graph;

typedef unordered_map < vertex, vector<vertex> > umapVec;                                      // for storing all K or S values of a vertex

typedef chrono::duration<double> tms;

struct subcore {
	bool visible;
	vertex rank;
	vertex K;
	vertex parent;
	vertex root;
	vector<vertex> children;
	vertex size;
	edge nEdge;
	double ed;

	subcore (vertex k) {
		K = k;
		rank = 0;
		parent = -1;
		root = -1;
		visible = true;
		size = 0;
		nEdge = 0;
		ed = -1;
	}
};

// Updated for Large Clique

struct helpers {
    
    vector<vp>* el;
    vector<vt>* tris;
    
    vector<vfour>* fc;
    vector<vfive>* fic;
    vector<vsix>* sc;
    vector<vseven>* sec;
    vector<veight>* ec;
    vector<vnine>* nc;
    
	helpers (vector<vp>* ael) {
		el = ael;
	}
    
    // 34
	helpers (vector<vt>* atris) {
		tris = atris;
	}
    // 45
    helpers (vector<vfour>* afc) {
        fc = afc;
    }
    
    // 56
    helpers (vector<vfive>* afic) {
        fic = afic;
    }
    
    // 67
    helpers (vector<vsix>* asc) {
        sc = asc;
    }
    
    // 78
    helpers (vector<vseven>* asec) {
        sec = asec;
    }
    
    // 89
    helpers (vector<veight>* aec) {
        ec = aec;
    }
    
    // 910
    helpers (vector<vnine>* anc) {
        nc = anc;
    }

	helpers () {}
};


template <class T>
inline void hash_combine(std::size_t & seed, const T & v)
{
	std::hash<T> hasher;
	seed ^= hasher(v) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
}

namespace std
{
template<typename S, typename T>
struct hash<pair<S, T>>
{
	inline size_t operator()(const pair<S, T> & v) const
	{
		size_t seed = 0;
		::hash_combine(seed, v.first);
		::hash_combine(seed, v.second);
		return seed;
	}
};
}

inline bool hashUniquify (vector<vertex>& vertices) {
	unordered_map<vertex, bool> hermap;
	for (size_t i = 0; i < vertices.size(); i++) {
		int t = vertices[i];
		if (hermap.find (t) == hermap.end())
			hermap[t] = true;
		else {
			vertices.erase (vertices.begin() + i);
			i--;
		}
		if (i > UPPERBOUND)
			return false;
	}
	sort (vertices.begin(), vertices.end());
	return true;
}


inline void print_time (FILE* fp, const string& str, tms t) {
	fprintf (fp, "%s %.6lf\n", str.c_str(), t.count());
	fflush(fp);
}


inline bool less_than (vertex u, vertex v, Graph& graph) {
    return (graph[u].size() < graph[v].size() || (graph[u].size() == graph[v].size() && u < v));
}


inline bool orderedConnected (Graph& graph, Graph& orderedGraph, vertex u, vertex v) {
	vertex a = u, b = v;
	if (less_than (v, u, graph))
		swap (a, b);
	for (auto c : orderedGraph[a])
		if (c == b)
			return true;
	return false;
}


//  Very important function - Create "orderedGraph" and "el", "xel" data structure
inline void createOrderedIndexEdges (Graph& graph, vector<vp>& el, vector<vertex>& xel, Graph& orderedGraph) {
    
	xel.push_back(0);
	orderedGraph.resize(graph.size());
    
	for (size_t u = 0; u < graph.size(); u++) {
		for (size_t j = 0; j < graph[u].size(); j++) {
			vertex v = graph[u][j];
			if (less_than (u, v, graph)) {  // less_than() is a function in this file
				orderedGraph[u].push_back(v);
				vp c (u, v);
				el.push_back(c);
			}
		}
		xel.push_back(el.size());  // saving the index for the starting of the edge list for a vertex
	}
}


inline void createOrdered (Graph& orderedGraph, Graph& graph) {
	orderedGraph.resize (graph.size());
	for (vertex i = 0; i < graph.size(); ++i)
		for (auto u : graph[i])
			if (less_than (i, u, graph))
				orderedGraph[i].push_back(u);
}



inline vertex getEdgeId (vertex u, vertex v, vector<vertex>& xel, vector<vp>& el, Graph& graph) {

	vertex a = u, b = v;
	if (less_than (b, a, graph))
		swap (a, b);

	for (vertex i = xel[a]; i < xel[a+1]; i++)
		if (el[i].second == b)
			return i;

	printf ("getEdgeId returns -1\n");
	exit(1);
}


// For finding the common neighbors between two vertices. Here, vector a and vector b holds the neighbor list of two vertices.
inline void intersection (vector<vertex>& a, vector<vertex>& b, vector<vertex>& c) {
	size_t i = 0, j = 0;
	while (i < a.size() && j < b.size()) {
		if (a[i] < b[j])
			i++;
		else if (b[j] < a[i])
			j++;
		else {
			c.push_back(a[i]);
			i++;
			j++;
		}
	}
}

// This function will store Kappa(K) values and S-clique frequency of R-cliques against vertex ID

inline void saveVertexProperty (vector<vertex>& V, umapVec& K, umapVec& S, vertex kValue, vertex sValue) {
    for(auto x: V){
        K[x].push_back(kValue);
        S[x].push_back(sValue);
    }
}

inline void writeVertexProperty (umapVec& K, umapVec& S, string fileName){
    
    ofstream out;
    out.open(fileName);
    
    for (auto x : K){
        
        out << "Vertex_ID: " << x.first;
        out << "\n";
        
        out << "Kappa # : ";
        for (auto i : x.second){
            out << i << " ";
        }
        
        out << "\n";
        
        out << "Frequency # : ";
        for (auto i : S[x.first]){
           out << i << " ";
        }
        
        out << "\n";
        out << "####################################";
        out << "\n";

    }
}

// This fucntion will print : Vertex_ID K_min K_max K_mean K_SD S_min S_max S_mean S_SD

inline void writeVertexStatistic (umapVec& K, umapVec& S, string fileName){
    
    vertex kMin, kMax, sMin, sMax;
    double kMean, sMean, kVar, sVar, kSD, sSD, sum, length;
    
    ofstream out;
    out.open(fileName);
    
    out << "Vertex_ID r-clique-count K-min K-max K-avg K-SD S-min S-max S-avg S-SD ";
    out << "\n";
    
    for (auto x : K){
        
        out << x.first << " ";         // Vertex_ID
        out << x.second.size() << " "; // r-clique-count
        
        // K-values
        kMin = x.second[0];
        kMax = x.second[0];
        kMean = 0.0;
        kVar = 0.0;
        kSD = 0.0;
        sum = 0.0;
        length = 0.0;
        
        for (auto i : x.second){
            if (i < kMin)
                kMin = i;
            if (i > kMax)
                kMax = i;
            
            sum += i;
            length++;
        }
        
        kMean = sum/length;
        
        for (auto i : x.second){
            kVar += (i - kMean)*(i - kMean);
        }
        kVar /= length;
        kSD = sqrt(kVar);
        
        out << kMin << " " << kMax << " " << kMean << " " << kSD << " ";   // kMin kMax kMean
        
        // S-values
        sMin = S[x.first][0];
        sMax = S[x.first][0];
        sMean = 0.0;
        sVar = 0.0;
        sSD = 0.0;
        sum = 0.0;
        length = 0.0;
        
        for (auto i : S[x.first]){
            if (i < sMin)
                sMin = i;
            if (i > sMax)
                sMax = i;
            
            sum = sum + i;
            length++;
        }
        
        sMean = sum/length;
        
        for (auto i : x.second){
            sVar += (i - sMean)*(i - sMean);
        }
        sVar /= length;
        sSD = sqrt(sVar);
        
        out << sMin << " " << sMax << " " << sMean << " " << sSD;
        out << "\n";
    }
    
    out.close();
}


// This fucntion will write : K_values S_values
inline void writeKSValues(vector<couple>& ks, string fileName){
    ofstream out;
    out.open(fileName);
    
    out << "K_values S_values";
    out << "\n";
    
    for(auto x : ks){
        out << get<0>(x) << " " << get<1>(x);
        out << "\n";
    }
    
}


//                                                      ###  Function prototypes  ###


template <typename VtxType, typename EdgeType>
void readGraph (char *filename, vector<vector<VtxType>>& graph, EdgeType* nEdge); // Function for reading the input file & save in a adjacency list. The function body is in the "graph.cpp" file

void base_kcore (Graph& graph, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* maxCore, string vfile, FILE* fp);
void base_k13   (Graph& graph, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* maxCore, string vfile, FILE* fp);
void base_k14   (Graph& graph, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* maxCore, string vfile, FILE* fp);

void base_ktruss (Graph& graph, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* maxtruss, string vfile, FILE* fp);
void base_ktruss_storeTriangles (Graph& graph, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* maxtruss, string vfile, FILE* fp);

void base_k24 (Graph& graph, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max24, string vfile, FILE* fp);
//void base_k34 (Graph& graph, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max34, string vfile, FILE* fp);

void base_k34  (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max34, string vfile, FILE* fp);
void base_k45  (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max45, string vfile, FILE* fp);
void base_k56  (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max56, string vfile, FILE* fp);
void base_k67  (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max67, string vfile, FILE* fp);
void base_k78  (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max78, string vfile, FILE* fp);
void base_k89  (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max89, string vfile, FILE* fp);
void base_k910 (Graph& graph, char *rCliqueFilename, char *sCliqueFilename, bool hierarchy, edge nEdge, vector<vertex>& K, vertex* max910, string vfile, FILE* fp);


void createSkeleton (vertex u, initializer_list<vertex> neighbors, vertex* nSubcores, vector<vertex>& K, vector<subcore>& skeleton,	vector<vertex>& component, vector<vertex>& unassigned, vector<vp>& relations);

void updateUnassigned (vertex t, vector<vertex>& component, vertex* cid, vector<vp>& relations, vector<vertex>& unassigned);

void buildHierarchy (vertex cn, vector<vp>& relations, vector<subcore>& skeleton, vertex* nSubcores, edge nEdge, vertex nVtx);

void presentNuclei (int variant, vector<subcore>& skeleton, vector<vertex>& component, Graph& graph, edge nEdge, helpers& ax, string vfile, FILE* gp);
