###  Nucleus Decomposition using Large Cliques



*  run `make -e -j12` command to compile the code



*  Command for running the exectuable files :

```

./nucleus <graph> <rCliqueFile> <sCliqueFile> <algorithm> <hierarchy?>

```



>  *  `<graph>` _is the input graph in matrix market (.mtx or .txt suffix) [1], SNAP [2] (out. prefix) or Chaco [3] (.graph suffix) format. It can be a binary file as well (See [4])_

>

>  *  `<rCliqueFile>` _is the file containing all r cliques of the input graph. Each line represents a r clique._

>

>  *  `<sCliqueFile>` _is the file containing all s cliques of the input graph. Each line represents a s clique._

>

>  *  `<algorithm>` _can be 12, 13, 14, 23, 34, 45, 56, 67, 78, 89, 910. First digit is the r value and second digit is the s value for (r, s)-nucleus decomposition. 12 is k-core, 23 is k-truss with triangle connectivity.

>

>  *  `<hierarchy>` _is YES or NO. YES computes the hierarchy, subgraphs, and densities. NO computes only K values._

>



* When `<hierarchy>` is YES, there are 2 output files :



* `<graph>_<algorithm>_Hierarchy`: Runtimes, statistics, and significantly dense subgraphs, i.e., subgraph is a leaf, its size is larger or equal to ****LOWERBOUND**** (set to 0 in main.h), and its density is at least ****THRESHOLD**** value (set to 0.0 in main.h)



* `<graph>_<algorithm>_NUCLEI`: Each line is a nucleus, first 6 numbers are subgraph id, K value, |V|, |E|, edge density, and 1 (0) if the nucleus is (not) a leaf in the hierarchy



- In the *-Hierarchy file, consider the following line;



`id: 17  K: 2  |V|: 7  |E|: 18  ed: 0.86  LEAF?: 1  parent id: 1  3 18 22 35 51 52 55 -1` <br />



It means the subgraph with id 17 has K value of 2, and it has 7 vertices, 18 edges with 0.86 edge density (18/(7 choose 2)). The subgraph is a leaf in the hierarchy and its parent is the subgraph with the id of 1. Following seven numbers are the vertices in the subgraph.



- Example:  `./nucleus adjnoun.mtx rCliques_adjnoun sClique_adjnoun 34 YES`  - does (3,4)-decomposition and hierarchy construction







##### Different Formats of input graph :



* [1]  Matrix market has "****.txt****" or "****.mtx****" suffix. Its format for a 4 clique: <br />



% First line is |V|, |E|  <br />



4 6 <br />

0 1 <br />

0 2 <br />

0 3 <br />

1 2 <br />

1 3 <br />

2 3 <br />



* [2] SNAP format has "****out.****" prefix. Its format for a 4 clique: <br />



0 1 <br />

0 2 <br />

0 3 <br />

1 2 <br />

1 3 <br />

2 3 <br />



* [3] Chaco format has "****.graph****" suffix. Its format for a 3 clique: <br />

% First line is |V|, |E|  <br />

% n-th line is a neighbor list of the vertex with id n-2  <br />



1 2 3 <br />

0 2 3 <br />

0 1 3 <br />

0 1 2 <br />



* [4] Activate ****WRITE_BINARY**** macro in `graph.cpp` to write binary graph files with "****.bin****" suffix -- recommended for `large graphs`
